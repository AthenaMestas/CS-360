package com.example.weighttrackingapp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.Locale

// Checks goal achievement and requests optional SMS alerts.
object GoalSmsNotifier {

    fun checkAndSend(
        context: Context,
        userId: Int,
        previousWeight: Double?,
        databaseHelper: DatabaseHelper
    ) {
        // Retrieve the user's goal and weight history.
        val starting = databaseHelper.getStartingWeight(userId)
            ?: return
        val current = databaseHelper.getCurrentWeight(userId)
            ?: return
        val goal = databaseHelper.getGoalWeight(userId)
            ?: return

        // Require a previous measurement and a meaningful goal.
        if (previousWeight == null || starting == goal) {
            return
        }

        // Identify whether the goal has just been reached.
        val wasReached = goalReached(
            previousWeight, starting, goal
        )

        val isReached = goalReached(
            current, starting, goal
        )

        if (wasReached || !isReached) {
            return
        }

        // Read this user's saved SMS preferences.
        val preferences = context.getSharedPreferences(
            "sms_settings",
            Context.MODE_PRIVATE
        )

        val enabled = preferences.getBoolean(
            "enabled_$userId", false
        )

        val phone = preferences.getString(
            "phone_$userId", ""
        ) ?: ""

        // Never send if the user has not opted in.
        if (!enabled || !Regex("^\\+?[0-9]{4,15}$").matches(phone)) {
            return
        }

        // Prevent repeated notifications for the same goal.
        val alertKey = "alerted_goal_$userId"
        val goalKey = goal.toString()

        if (preferences.getString(alertKey, null) == goalKey) {
            return
        }

        // Check whether Android has granted SMS permission.
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        // SMS requires a device with messaging capability.
        if (!context.packageManager.hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY_MESSAGING
            )
        ) {
            return
        }

        val message = String.format(
            Locale.US,
            "Weight Tracker: Congratulations! " +
                    "You reached your goal weight of %.1f lbs!",
            goal
        )

        try {
            // Use the system SMS service on newer Android versions.
            val smsManager = if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            ) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            // Request SMS transmission.
            smsManager.sendTextMessage(
                phone,
                null,
                message,
                null,
                null
            )

            // Record that a request was made for this goal.
            preferences.edit()
                .putString(alertKey, goalKey)
                .apply()

            Toast.makeText(
                context,
                "Goal reached! SMS send requested.",
                Toast.LENGTH_LONG
            ).show()

        } catch (e: RuntimeException) {
            // The weight entry remains saved if SMS fails.
            Log.e("GoalSmsNotifier", "SMS request failed", e)

            Toast.makeText(
                context,
                "Goal reached, but SMS could not be sent.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // Support both weight-loss and weight-gain goals.
    private fun goalReached(
        weight: Double,
        starting: Double,
        goal: Double
    ): Boolean {
        return if (goal < starting) {
            weight <= goal
        } else {
            weight >= goal
        }
    }
}