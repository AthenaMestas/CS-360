package com.example.weighttrackingapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

// Handles both adding new weights and editing saved entries.
class AddWeightActivity : AppCompatActivity() {

    private var userId = -1
    private var editingWeightId = -1

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var editDate: EditText
    private lateinit var editWeight: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_weight)

        // Identify the logged-in user and optional record to edit.
        userId = intent.getIntExtra("USER_ID", -1)
        editingWeightId = intent.getIntExtra("WEIGHT_ID", -1)

        if (userId == -1) {
            showMessage("Please log in first.")
            finish()
            return
        }

        databaseHelper = DatabaseHelper(this)

        editDate = findViewById(R.id.editDate)
        editWeight = findViewById(R.id.editWeight)

        val buttonSave: Button = findViewById(R.id.buttonSave)
        val buttonCancel: Button = findViewById(R.id.buttonCancel)

        // Determine whether the screen is adding or editing.
        if (editingWeightId != -1) {

            // Prefill fields using the selected record.
            editDate.setText(
                intent.getStringExtra("ENTRY_DATE") ?: ""
            )

            val existingWeight =
                intent.getDoubleExtra("WEIGHT_VALUE", 0.0)

            editWeight.setText(existingWeight.toString())

            findViewById<TextView>(
                R.id.textHeaderAddWeight
            ).text = "Edit Weight Entry"

            buttonSave.text = "Save Changes"

        } else {

            // Use today's date for a new record.
            editDate.setText(LocalDate.now().toString())
        }

        buttonSave.setOnClickListener {
            saveWeight()
        }

        buttonCancel.setOnClickListener {
            finish()
        }
    }

    // Validate inputs, then insert or update the weight record.
    private fun saveWeight() {
        val date = editDate.text.toString().trim()
        val weightInput = editWeight.text.toString().trim()

        if (date.isEmpty() || weightInput.isEmpty()) {
            showMessage("Please enter a date and weight.")
            return
        }

        try {
            LocalDate.parse(
                date,
                DateTimeFormatter.ISO_LOCAL_DATE
            )
        } catch (e: DateTimeParseException) {
            showMessage("Use date format YYYY-MM-DD.")
            return
        }

        val weight = weightInput.toDoubleOrNull()

        if (weight == null || !weight.isFinite() || weight <= 0) {
            showMessage("Please enter a valid weight.")
            return
        }

        // Remember the previous weight to detect goal achievement.
        val previousWeight = databaseHelper.getCurrentWeight(userId)

        if (editingWeightId != -1) {

            // Update the existing record instead of adding another.
            val updatedRows = databaseHelper.updateWeight(
                editingWeightId,
                userId,
                date,
                weight
            )

            if (updatedRows > 0) {
                showMessage("Weight updated successfully!")

                // Check whether the updated weight reaches the goal.
                GoalSmsNotifier.checkAndSend(
                    this,
                    userId,
                    previousWeight,
                    databaseHelper
                )

                finish()
            }
            else {
                showMessage("Unable to update weight.")
            }

        } else {

            // Insert a new record for this user.
            val recordId = databaseHelper.addWeight(
                userId,
                date,
                weight
            )

            if (recordId != -1L) {
                showMessage("Weight saved successfully!")

                // Check for goal achievement after saving.
                GoalSmsNotifier.checkAndSend(
                    this,
                    userId,
                    previousWeight,
                    databaseHelper
                )

                finish()
            }
            else {
                showMessage("Unable to save weight.")
            }
        }
    }

    private fun showMessage(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDestroy() {
        if (::databaseHelper.isInitialized) {
            databaseHelper.close()
        }
        super.onDestroy()
    }
}