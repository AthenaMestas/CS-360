package com.example.weighttrackingapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Base64;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

// Manages the application's local SQLite database.
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracking.db";
    private static final int DATABASE_VERSION = 1;

    // Creates the database helper using the application context.
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);

        // Enforce relationships between users and weight records.
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store user accounts, secure password data, and goal weights.
        String createUsersTable =
                "CREATE TABLE users (" +
                        "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash TEXT NOT NULL, " +
                        "password_salt TEXT NOT NULL, " +
                        "goal_weight REAL)";

        db.execSQL(createUsersTable);

        // Store daily weight entries belonging to each user.
        String createWeightsTable =
                "CREATE TABLE weights (" +
                        "weight_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "entry_date TEXT NOT NULL, " +
                        "weight_value REAL NOT NULL, " +
                        "FOREIGN KEY(user_id) REFERENCES users(user_id) " +
                        "ON DELETE CASCADE)";

        db.execSQL(createWeightsTable);
    }


    // Save a new weight entry for the specified user.
    public long addWeight(int userId, String date, double weight) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", date);
        values.put("weight_value", weight);

        return db.insert("weights", null, values);
    }

    // Retrieve all weight records belonging to one user.
    // The caller must close the returned Cursor.
    public Cursor getWeights(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                "weights",
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "entry_date DESC, weight_id DESC"
        );
    }

    // Update an existing record belonging to the specified user.
    public int updateWeight(int weightId, int userId,
                            String date, double weight) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("entry_date", date);
        values.put("weight_value", weight);

        return db.update(
                "weights",
                values,
                "weight_id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(weightId),
                        String.valueOf(userId)
                }
        );
    }

    // Delete a weight record belonging to the specified user.
    public int deleteWeight(int weightId, int userId) {

        SQLiteDatabase db = getWritableDatabase();

        return db.delete(
                "weights",
                "weight_id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(weightId),
                        String.valueOf(userId)
                }
        );
    }


    // Create a new user account and store a salted password hash.
    // Returns the new user ID or -1 if registration fails.
    public long createUser(String username, String password) {

        if (username == null || password == null ||
                username.trim().isEmpty() || password.isEmpty()) {
            return -1;
        }

        try {
            // Generate a unique random salt for this user.
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            String storedSalt = Base64.encodeToString(
                    salt, Base64.NO_WRAP);

            String storedHash = hashPassword(password, salt);

            ContentValues values = new ContentValues();
            values.put("username", username.trim());
            values.put("password_hash", storedHash);
            values.put("password_salt", storedSalt);

            SQLiteDatabase db = getWritableDatabase();

            return db.insert("users", null, values);

        } catch (GeneralSecurityException e) {
            return -1;
        }
    }

    // Verify login details against the saved user account.
    // Returns the user ID when successful, or -1 otherwise.
    public int verifyLogin(String username, String password) {

        if (username == null || password == null) {
            return -1;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                "users",
                new String[]{
                        "user_id", "password_hash", "password_salt"
                },
                "username = ?",
                new String[]{username.trim()},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return -1;
            }

            int userId = cursor.getInt(0);
            String storedHash = cursor.getString(1);
            String storedSalt = cursor.getString(2);

            byte[] salt = Base64.decode(
                    storedSalt, Base64.NO_WRAP);

            String enteredHash = hashPassword(password, salt);

            // Compare the derived password hashes.
            if (java.security.MessageDigest.isEqual(
                    Base64.decode(storedHash, Base64.NO_WRAP),
                    Base64.decode(enteredHash, Base64.NO_WRAP))) {

                return userId;
            }

        } catch (GeneralSecurityException |
                 IllegalArgumentException e) {
            return -1;
        }

        return -1;
    }

    // Derive a password hash using PBKDF2 and a unique salt.
    private String hashPassword(String password, byte[] salt)
            throws GeneralSecurityException {

        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(),
                salt,
                100000,
                256
        );

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA1");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return Base64.encodeToString(hash, Base64.NO_WRAP);

        } finally {
            spec.clearPassword();
        }
    }

    // Save or change the user's goal weight.
    public boolean saveGoalWeight(int userId, double goalWeight) {
        if (!Double.isFinite(goalWeight) || goalWeight <= 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);

        int rowsUpdated = getWritableDatabase().update(
                "users",
                values,
                "user_id = ?",
                new String[]{String.valueOf(userId)}
        );

        return rowsUpdated > 0;
    }

    // Retrieve the user's saved goal, if one exists.
    public Double getGoalWeight(int userId) {
        try (Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"goal_weight"},
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null, null, null)) {

            if (cursor.moveToFirst() && !cursor.isNull(0)) {
                return cursor.getDouble(0);
            }
        }

        return null;
    }

    // Get the earliest dated weight as the starting weight.
    public Double getStartingWeight(int userId) {
        return getBoundaryWeight(userId, true);
    }

    // Get the most recent dated weight.
    public Double getCurrentWeight(int userId) {
        return getBoundaryWeight(userId, false);
    }

    // Shared query for the earliest or latest weight.
    private Double getBoundaryWeight(int userId, boolean earliest) {
        String sortOrder = earliest
                ? "entry_date ASC, weight_id ASC"
                : "entry_date DESC, weight_id DESC";

        try (Cursor cursor = getReadableDatabase().query(
                "weights",
                new String[]{"weight_value"},
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null, null, sortOrder, "1")) {

            if (cursor.moveToFirst()) {
                return cursor.getDouble(0);
            }
        }

        return null;
    }

    // Handles future database version upgrades.
    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {

        // Version 1 does not require database migrations.
        // Future schema changes can be handled here.
    }
}
