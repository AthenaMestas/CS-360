
package com.example.weighttrackingapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent // Allows for navigation between activities

class MainActivity : AppCompatActivity() {

    // Provides access to the local SQLite database.
    private lateinit var databaseHelper: DatabaseHelper

    // References the existing login screen fields.
    private lateinit var editUsername: EditText
    private lateinit var editPassword: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Adjust the layout around system navigation bars.
        ViewCompat.setOnApplyWindowInsetsListener(
            findViewById(R.id.main)
        ) { view, insets ->
            val systemBars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars()
            )

            view.setPadding(
                systemBars.left,
                systemBars.top,
                systemBars.right,
                systemBars.bottom
            )

            insets
        }

        // Initialize the database helper.
        databaseHelper = DatabaseHelper(this)

        // Connect Kotlin code to existing XML components.
        editUsername = findViewById(R.id.editUsername)
        editPassword = findViewById(R.id.editPassword)

        val buttonLogin: Button = findViewById(R.id.buttonLogin)
        val buttonCreateAccount: Button =
            findViewById(R.id.buttonCreateAccount)

        // Attempt login when the user presses Log In.
        buttonLogin.setOnClickListener {
            loginUser()
        }

        // Register a new user when Create Account is pressed.
        buttonCreateAccount.setOnClickListener {
            createAccount()
        }
    }

    // Checks entered credentials against stored user accounts.
    private fun loginUser() {
        val username = editUsername.text.toString().trim()
        val password = editPassword.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            showMessage("Please enter a username and password.")
            return
        }

        // Returns the user ID when credentials are valid.
        val userId = databaseHelper.verifyLogin(
            username,
            password
        )

        if (userId != -1) {
            showMessage("Login successful! Welcome, $username!")

            // Open the Weight Records screen for this user.
            val intent = Intent(this, WeightRecordsActivity::class.java)

            // Pass the logged-in user's database ID.
            intent.putExtra("USER_ID", userId)

            startActivity(intent)

        } else {
            showMessage("Incorrect username or password.")
        }
    }

    // Creates and saves a new account in the SQLite database.
    private fun createAccount() {
        val username = editUsername.text.toString().trim()
        val password = editPassword.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            showMessage("Please enter a username and password.")
            return
        }

        // Save the new account using DatabaseHelper.
        val newUserId = databaseHelper.createUser(
            username,
            password
        )

        if (newUserId != -1L) {
            showMessage("Account created! You can now log in.")

            // Clear the password field after registration.
            editPassword.text.clear()

        } else {
            showMessage(
                "Unable to create account. Username may already exist."
            )
        }
    }

    // Displays short feedback messages to the user.
    private fun showMessage(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDestroy() {
        databaseHelper.close()
        super.onDestroy()
    }
}
