package com.example.weighttrackingapp

import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import android.content.Intent
import android.widget.LinearLayout
import android.widget.ImageButton
import android.widget.EditText
import android.widget.ProgressBar

// Displays database records for the currently logged-in user.
class WeightRecordsActivity : AppCompatActivity() {

    private var userId = -1
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var recordsGrid: GridLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_records)

        // Retrieve the logged-in user's database ID.
        userId = intent.getIntExtra("USER_ID", -1)

        if (userId == -1) {
            Toast.makeText(
                this, "Please log in first.", Toast.LENGTH_SHORT
            ).show()
            finish()
            return
        }

        // Initialize the database and dynamic records grid.
        databaseHelper = DatabaseHelper(this)
        recordsGrid = findViewById(R.id.gridWeightRecords)

        // Connect the goal-weight field and Save Goal button.
        val goalInput: EditText = findViewById(R.id.editGoalWeight)
        val buttonSaveGoal: Button = findViewById(R.id.buttonSaveGoal)

// Save the user's goal weight to SQLite.
        buttonSaveGoal.setOnClickListener {

            val goal = goalInput.text.toString().trim().toDoubleOrNull()

            // Reject empty, invalid, or nonpositive weights.
            if (goal == null || !goal.isFinite() || goal <= 0) {
                Toast.makeText(
                    this,
                    "Please enter a valid goal weight.",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                // Store the goal under the logged-in user's account.
                val saved = databaseHelper.saveGoalWeight(userId, goal)

                if (saved) {
                    Toast.makeText(
                        this,
                        "Goal weight saved!",
                        Toast.LENGTH_SHORT
                    ).show()

                    // Immediately update the screen.
                    refreshGoalDisplay()

                } else {
                    Toast.makeText(
                        this,
                        "Unable to save goal weight.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // Connect the Add Weight button to its XML component.
        val buttonAddWeight: Button = findViewById(R.id.buttonAddWeight)

        // Open the Add Weight screen when the button is pressed.
        buttonAddWeight.setOnClickListener {

            val intent = Intent(this, AddWeightActivity::class.java)

            // Pass the current user ID so the new record
            // belongs to the logged-in account.
            intent.putExtra("USER_ID", userId)

            startActivity(intent)
        }
        // Open the optional SMS notification settings screen.
        val buttonSmsSettings: Button =
            findViewById(R.id.buttonSmsSettings)

        buttonSmsSettings.setOnClickListener {
            val smsIntent = Intent(
                this,
                SmsPermissionActivity::class.java
            )

            smsIntent.putExtra("USER_ID", userId)
            startActivity(smsIntent)
        }
    }

    // Refresh the grid using the latest SQLite records.
    private fun loadWeightRecords() {
        recordsGrid.removeAllViews()

        databaseHelper.getWeights(userId).use { cursor ->

            val idColumn = cursor.getColumnIndexOrThrow("weight_id")
            val dateColumn = cursor.getColumnIndexOrThrow("entry_date")
            val weightColumn =
                cursor.getColumnIndexOrThrow("weight_value")

            if (!cursor.moveToFirst()) {
                val emptyMessage = TextView(this).apply {
                    text = "No weight entries yet."
                    textSize = 16f
                    gravity = android.view.Gravity.CENTER
                    setPadding(12, 20, 12, 20)
                }

                // Span all three grid columns and center the message.
                val params = GridLayout.LayoutParams(
                    GridLayout.spec(0),
                    GridLayout.spec(0, 3)
                ).apply {
                    width = GridLayout.LayoutParams.MATCH_PARENT
                    height = GridLayout.LayoutParams.WRAP_CONTENT
                }

                recordsGrid.addView(emptyMessage, params)
                return@use
            }

            do {
                val weightId = cursor.getInt(idColumn)
                val date = cursor.getString(dateColumn)
                val weight = cursor.getDouble(weightColumn)

                addRecordRow(weightId, date, weight)

            } while (cursor.moveToNext())
        }
    }

    // Create a grid row with the date, weight, and Edit/Delete actions.
    private fun addRecordRow(
        weightId: Int,
        date: String,
        weight: Double
    ) {
        val dateText = TextView(this).apply {
            text = date
            textSize = 14f
            gravity = android.view.Gravity.CENTER
            setPadding(8, 16, 8, 16)
        }

        val weightText = TextView(this).apply {
            text = String.format(
                Locale.US, "%.1f lbs", weight
            )
            textSize = 14f
            gravity = android.view.Gravity.CENTER
            setPadding(8, 16, 8, 16)
        }

        val editButton = ImageButton(this).apply {

            // Display the centered pencil icon.
            setImageResource(R.drawable.ic_edit)
            scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            setPadding(12, 12, 12, 12)

            // Give the button a color matching the app theme.
            backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(
                        this@WeightRecordsActivity,
                        R.color.stone
                    )
                )

            contentDescription = "Edit weight entry"

            // Open the selected record for editing.
            setOnClickListener {
                val intent = Intent(
                    this@WeightRecordsActivity,
                    AddWeightActivity::class.java
                )

                intent.putExtra("USER_ID", userId)
                intent.putExtra("WEIGHT_ID", weightId)
                intent.putExtra("ENTRY_DATE", date)
                intent.putExtra("WEIGHT_VALUE", weight)

                startActivity(intent)
            }
        }

        val deleteButton = ImageButton(this).apply {
            // Display the centered trash icon.
            setImageResource(R.drawable.ic_delete)
            scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            setPadding(12, 12, 12, 12)

            backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(
                        this@WeightRecordsActivity,
                        R.color.stone
                    )
                )

            contentDescription = "Delete weight entry"

            // Delete only the weight record associated with this button.
            setOnClickListener {
                val deletedRows = databaseHelper.deleteWeight(
                    weightId,
                    userId
                )

                if (deletedRows > 0) {
                    Toast.makeText(
                        this@WeightRecordsActivity,
                        "Weight deleted.",
                        Toast.LENGTH_SHORT
                    ).show()

                    // Refresh the grid after deletion.
                    loadWeightRecords()

                    refreshGoalDisplay()
                } else {
                    Toast.makeText(
                        this@WeightRecordsActivity,
                        "Unable to delete weight.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // Give each grid column one-third of the available width.
        val dateParams = GridLayout.LayoutParams(
            GridLayout.spec(GridLayout.UNDEFINED),
            GridLayout.spec(0, 1, 1f)
        ).apply {
            width = 0
            height = GridLayout.LayoutParams.WRAP_CONTENT
        }

        val weightParams = GridLayout.LayoutParams(
            GridLayout.spec(GridLayout.UNDEFINED),
            GridLayout.spec(1, 1, 1f)
        ).apply {
            width = 0
            height = GridLayout.LayoutParams.WRAP_CONTENT
        }

        val deleteParams = GridLayout.LayoutParams(
            GridLayout.spec(GridLayout.UNDEFINED),
            GridLayout.spec(2, 1, 1f)
        ).apply {
            width = 0
            height = GridLayout.LayoutParams.WRAP_CONTENT
        }

        // Group Edit and Delete in the same Action column.
        val actionButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER

            addView(
                editButton,
                LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            )

            addView(
                deleteButton,
                LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            )
        }

        recordsGrid.addView(dateText, dateParams)
        recordsGrid.addView(weightText, weightParams)
        recordsGrid.addView(actionButtons, deleteParams)
    }

    // Refresh goal information using the user's saved SQLite data.
    private fun refreshGoalDisplay() {

        // Retrieve the earliest weight, latest weight, and saved goal.
        val starting = databaseHelper.getStartingWeight(userId)
        val current = databaseHelper.getCurrentWeight(userId)
        val goal = databaseHelper.getGoalWeight(userId)

        // Connect to the existing XML components.
        val startingText: TextView =
            findViewById(R.id.textStartingWeight)

        val goalText: TextView =
            findViewById(R.id.textGoalWeight)

        val goalInput: EditText =
            findViewById(R.id.editGoalWeight)

        val progressBar: ProgressBar =
            findViewById(R.id.progressBar)

        // Display the user's earliest recorded weight.
        startingText.text = if (starting != null) {
            String.format(
                Locale.US,
                "Starting: %.1f lbs",
                starting
            )
        } else {
            "Starting: --"
        }

        // Display the saved goal weight.
        goalText.text = if (goal != null) {
            String.format(
                Locale.US,
                "Goal: %.1f lbs",
                goal
            )
        } else {
            "Goal: Not set"
        }

        // Restore the user's saved goal into the input field.
        goalInput.setText(
            if (goal != null) {
                String.format(Locale.US, "%.1f", goal)
            } else {
                ""
            }
        )

        // Calculate progress toward the goal.
        val progress = if (
            starting != null &&
            current != null &&
            goal != null
        ) {
            if (starting == goal) {
                if (current == goal) 100 else 0
            } else {
                (((current - starting) /
                        (goal - starting)) * 100)
                    .toInt()
                    .coerceIn(0, 100)
            }
        } else {
            0
        }

        // Display progress from 0 to 100 percent.
        progressBar.progress = progress
    }

    // Refresh records whenever the user returns to this screen.
    // Refresh weight records and goal progress when returning.
    override fun onResume() {
        super.onResume()

        if (::databaseHelper.isInitialized && userId != -1) {
            loadWeightRecords()
            refreshGoalDisplay()
        }
    }

    override fun onDestroy() {
        if (::databaseHelper.isInitialized) {
            databaseHelper.close()
        }
        super.onDestroy()
    }
}
