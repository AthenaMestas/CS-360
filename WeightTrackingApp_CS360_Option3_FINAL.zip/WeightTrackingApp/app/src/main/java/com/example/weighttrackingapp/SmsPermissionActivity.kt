package com.example.weighttrackingapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

// Allows users to enable or decline optional SMS notifications.
class SmsPermissionActivity : AppCompatActivity() {

    private var userId = -1
    private lateinit var editSmsPhone: EditText
    private var pendingPhone = ""

    // Handle the Android SMS permission dialog.
    private val permissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->

            if (granted) {
                saveSmsPreference()
            } else {
                showMessage(
                    "SMS permission denied. " +
                            "Weight tracking will still work."
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_permission)

        // Identify the logged-in user.
        userId = intent.getIntExtra("USER_ID", -1)

        if (userId == -1) {
            finish()
            return
        }

        editSmsPhone = findViewById(R.id.editSmsPhone)

        val buttonAllow: Button =
            findViewById(R.id.buttonAllowSms)

        val buttonDecline: Button =
            findViewById(R.id.buttonDeclineSMS)

        // Restore the phone number previously entered by this user.
        val preferences = getSharedPreferences(
            "sms_settings",
            MODE_PRIVATE
        )

        editSmsPhone.setText(
            preferences.getString("phone_$userId", "")
        )

        buttonAllow.setOnClickListener {

            // Normalize common phone-number separators.
            val enteredPhone = editSmsPhone.text.toString()
            pendingPhone = enteredPhone.filter {
                it.isDigit() || it == '+'
            }

            // Four-digit numbers also support emulator SMS testing.
            if (!Regex("^\\+?[0-9]{4,15}$").matches(pendingPhone)) {
                editSmsPhone.error = "Enter a valid phone number."
                return@setOnClickListener
            }

            // Ask Android for permission only when needed.
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                saveSmsPreference()
            } else {
                permissionLauncher.launch(
                    Manifest.permission.SEND_SMS
                )
            }
        }

        // Keep SMS disabled if the user declines.
        buttonDecline.setOnClickListener {
            preferences.edit()
                .putBoolean("enabled_$userId", false)
                .apply()

            showMessage("SMS notifications disabled.")
            finish()
        }
    }

    // Save the user's explicit choice and recipient number.
    private fun saveSmsPreference() {
        getSharedPreferences("sms_settings", MODE_PRIVATE)
            .edit()
            .putBoolean("enabled_$userId", true)
            .putString("phone_$userId", pendingPhone)
            .apply()

        showMessage("SMS notifications enabled!")
        finish()
    }

    private fun showMessage(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }
}